package servlet.registration.controller;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import jakarta.servlet.annotation.WebServlet;

import jakarta.servlet.RequestDispatcher;
import servlet.registration.dao.EmployeeDao;
import servlet.registration.model.Employee;

/**
 * Servlet implementation class EmployeeServlet
 */
@WebServlet("/register")
public class EmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private EmployeeDao employeeDao;

	public void init() {
		employeeDao = new EmployeeDao();
	}

	protected void doGet(HttpServletRequest request , HttpServletResponse response) throws ServletException, IOException{
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF//views/employeeregister.jsp");
		dispatcher.forward(request, response);
	}
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String name = request.getParameter("name");
		String age = request.getParameter("age");
		String gender = request.getParameter("gender");
		String email = request.getParameter("email");
		String designation = request.getParameter("designation");
		String department = request.getParameter("department");

		Employee employee = new Employee();
		employee.setName(name);
		employee.setAge(age);
		employee.setGender(gender);
		employee.setEmail(email);
		employee.setDesignation(designation);
		employee.setDepartment(department);
 
		try {
			employeeDao.registerEmployee(employee);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF//views/employeedetails.jsp");
		dispatcher.forward(request, response);
	}
}
